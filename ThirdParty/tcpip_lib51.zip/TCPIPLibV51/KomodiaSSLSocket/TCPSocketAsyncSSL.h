/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#if !defined(AFX_TCPSOCKETASYNCSSL_H__551A1459_9C4D_44CD_B8B3_C062C9661384__INCLUDED_)
#define AFX_TCPSOCKETASYNCSSL_H__551A1459_9C4D_44CD_B8B3_C062C9661384__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <deque>

#ifdef _SSLInheritance
#include "TCPSocketAsyncMsg.h"
#else
#include "TCPSocketAsync.h"
#endif

KOMODIA_NAMESPACE_START

class CGenericCriticalSection;

struct SSLData;

#ifdef _SSLInheritance
typedef CTCPSocketAsyncMsg SSLBaseClass;
#else
typedef CTCPSocketAsync SSLBaseClass;
#endif

class CTCPSocketAsyncSSL : public SSLBaseClass
{
public:
	//Load a certificate store (must be a PEM file)
	//Visit http://curl.haxx.se/docs/caextract.html to get most up to date file
	//Make sure to first call Create()
	bool LoadCertificateStore(const std::string& rPEMPath);

	//Load certificates for a server socket (only if you want to create https server, and call "listen")
	//No need to set it for client that uses "connect" method
	//rPublicKey - .PEM file of the public key
	//rPrivateKey - .PEM file of the private key
	//Make sure to first call Create()
	//To learn how to get these files you can visit: http://panoptic.com/wiki/aolserver/How_to_generate_self-signed_SSL_certificates
	bool LoadCertificatesForServer(const std::string& rPublicKey,
								   const std::string& rPrivateKey);

	//Is ready for send, while session not yet established
	//Can we try to send
	bool IsReadyForSend()const;

	//Did we finish the handshake
	bool IsHandshakeComplete()const;

	//Set socket to not deque
	void DontQueue();

	//Create the socket
	//Must be called before any SSL operations are made
	virtual BOOL Create();

	//Accept a connection, supply an already made socket
	virtual BOOL Accept(CTCPSocket* pNewSocket);

	//Connect with default source port as zero
	//bDisableAsync - Connect blockingly to destination
	//				  (user event will not be called)
	//bForceErrorEvent - Will call OnSocketConnect event if an
	//					 immediate error occured (only if bDisableAsync==FALSE)
	//Connect will only spawn the OnSocketConnect event after the socket has been connected
	//This doesn't work with the flag bDisableAsync
	virtual BOOL Connect(IP aDestinationAddress,
						 unsigned short usDestinationPort,
						 BOOL bDisableAsync=FALSE,
						 BOOL bForceErrorEvent=FALSE);
	virtual BOOL Connect(const std::string& rDestinationAddress,
						 unsigned short usDestinationPort,
						 BOOL bDisableAsync=FALSE,
						 BOOL bForceErrorEvent=FALSE);

	//Our async connection
	virtual BOOL Connect(unsigned short usSourcePort,
						 IP aDestinationAddress,
						 unsigned short usDestinationPort,
						 BOOL bDisableAsync=FALSE,
						 BOOL bForceErrorEvent=FALSE);
	virtual BOOL Connect(unsigned short usSourcePort,
						 const std::string& rDestinationAddress,
						 unsigned short usDestinationPort,
						 BOOL bDisableAsync=FALSE,
						 BOOL bForceErrorEvent=FALSE);

	//Send data over the sockets
	//Send may fail because the system isn't ready to 
	//send the data, check out the value of the send
	//SOCKET_ERROR - Failure
	//0 - Send couldn't finish because it would block
	//    if there was a blocking buffer, it was queued
	//	  (check out AllowBlockedBuffer in CAsyncSocket)
	//-2 - Still in SSL operations, data is buffered and will be sent as soon as possible
	//Value - Bytes sent, actual size may differe because of SSL encryption
	//This method will encrypt the data
	virtual int Send(const char* pBuffer,
					 unsigned long ulBufferLength);

	//Recieve data from remote socket, can be used with all
	//sub sockets (protocols)
	//Return value:
	//Positive - The number of bytes received.
	//Zero - No data to receive.
	//-2 - Still in SSL operations, no data available yet
	//Negative - Error
	//This method will decrypt the data
	virtual int Receive(char* pBuffer,
						unsigned long ulBufferLength);

	//Get data from remote socket with out deleting data from buffer
	//Return value:
	//Positive - The number of bytes received.
	//Zero - No data to receive.
	//Negative - Error
	virtual int Peek(char* pBuffer,
					 unsigned long ulBufferLength);

	//Initialize the SSL engine, must be called before using any SSL enabled classes
	static void InitializeSSL();

	//Uninitialize the SSL engine, must be called before the application exits
	static void UninitializeSSL();

	//Disable SSL, incase wasn't called in CTor
	//Must be called before Create
	void DisableSSL();

	//Ctor and Dtor
	//bDisableSSL - If true, socket will act as a normal socket
	CTCPSocketAsyncSSL(bool bDisableSSL=false);
	virtual ~CTCPSocketAsyncSSL();
protected:
	//SSL Possible events
	typedef enum _SSLEvents
	{
		seBadCertificate=0, //Handshake is complete, user needs to decide if he wants this session or not
		seHandshakeFinished
	} SSLEvents;
protected:
	//Method to receive SSL errors
	//Return value: True - Terminate connection, false - keep alive
	virtual bool OnSSLError(const std::string& rMethod,
							const std::string& rMessage,
							const std::string& rSSLError)const;

	//Method to receive completion of handshake
	//If handshake is finished it means that the hashes are OK
	//Certificate can be invalid, but it's only checked if the method LoadCertificateStore was called
	virtual void OnSSLEvent(SSLEvents)const;

	//Event handler for socket connections
	virtual BOOL SocketConnected(int iErrorCode,
								 BOOL bNoEvent);

	//Event handler for socket receive
	virtual BOOL SocketReceive(int iErrorCode,
							   BOOL bNoEvent);

	//When we have data to write
	virtual BOOL SocketWrite(int iErrorCode);
private:
	//Our data deque
	typedef std::deque<char> DataDeque;
private:
	//Flush the data in the queue
	int FlushData();

	//Handle an SSL error
	//Will return true if need to ignore this error
	bool HandleSSLError(const std::string& rMethod,
						const std::string& rMessage,
						int iResult,
						bool& rKeepAlive,
						bool& rSSLWantRead)const;

	//Get data from the deque
	int GetDataFromDeque(DataDeque& rDeque,
						 char* pData,
						 int iDataSize)const;

	//Add data to deque
	void AddDataToDeque(DataDeque& rDeque,
						const char* pData,
						int iDataSize,
						bool bBack=false)const;

	//Local send function
	int LocalSend(const char* pBuffer,
			  	  unsigned long ulBufferLength,
				  bool bDontDeque,
				  bool bDontFlush);

	//Local receive function
	int LocalReceive(char* pBuffer,
					 unsigned long ulBufferLength,
					 bool bFlush);

	//Flush the SSL data we have so far
	int FlushSSLWrite();

	//Flush the pending non encryped data
	int FlushWrite();

	//Set father, for server sockets
	void SetFather(CTCPSocketAsyncSSL* pFather);

	//Create the SSL data
	void CreateSSLData();

	//Send initial SSL data
	//Then SSL must initiate the start of handshake
	void StartSSLHandshake();

	//Our SSL data
	SSLData* m_pData;

	//Our CS, for general purposes
	CGenericCriticalSection* m_pCS;

	//Our CS, for reading and writing the read deque
	CGenericCriticalSection* m_pCSWrite;

	//Pending data to write (plain text the SSL rejected)
	DataDeque m_aPendingDataWrite;

	//Our data to write (SSL encrypted)
	DataDeque m_aDataToWrite;

	//Our data to read (plain text that the SSL decrypted)
	DataDeque m_aDataToRead;

	//Did we finish the session
	bool m_bSession;

	//Do we need to verify the certificate?
	bool m_bVerify;

	//Do we have server certificate?
	bool m_bServerCert;

	//Did we had any send?
	//Needed to know if we can send SSL handshake
	//Incase user explicitly asks for this
	bool m_bSend;

	//Our father, for server sockets
	//So we can use the SSL context var
	CTCPSocketAsyncSSL* m_pFather;

	//Do we have SSL disabled
	bool m_bDisableSSL;

	//Save event status
	bool m_bEvent;

	//Did we had the event spawn?
	bool m_bEventSpawned;

	//An option to not queue data, upper layer will try to resend again if something went wrong
	bool m_bDontQueue;

	//Can send data?
	bool m_bCanSend;
};

KOMODIA_NAMESPACE_END

#endif // !defined(AFX_TCPSOCKETASYNCSSL_H__551A1459_9C4D_44CD_B8B3_C062C9661384__INCLUDED_)
