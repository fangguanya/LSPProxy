/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#pragma warning(disable:4786)

#include <winsock2.h>
#include <windows.h>

#include "TCPSocketAsyncBlowFish.h"

#ifdef _DEBUG
#include "DebugHeap.h"
#endif

KOMODIA_NAMESPACE_START

CTCPSocketAsyncBlowFish::CTCPSocketAsyncBlowFish() : m_aEncryptChain(0xC009F158,0x17EC17EC),
													 m_aDecryptChain(0xC009F158,0x17EC17EC)
{
}

CTCPSocketAsyncBlowFish::~CTCPSocketAsyncBlowFish()
{
}

void CTCPSocketAsyncBlowFish::SetKey(const std::string& rKey)
{
	//Save the key
	m_sKey=rKey;
}

int CTCPSocketAsyncBlowFish::ReceiveMsg(char* pData,
									    int iSize,
									    int& iMoreMessages)
{
	//Call upper layer
	int iResult;
	iResult=BlowFishBaseClass::ReceiveMsg(pData,
										  iSize,
										  iMoreMessages);

	//Did we get it?
	if (iResult<=0)
		return iResult;

	//Try to decrypt the message
	if (!DecryptMemory(pData,
					   iResult))
		return -4;

	//Get the original size
	int iOriginalSize;
	memcpy(&iOriginalSize,
		   pData,
		   sizeof(iOriginalSize));

	//Check size makes sense
	if (iOriginalSize>iResult ||
		iOriginalSize<0)
		//Encryption problem
		return -4;

	//Move the memory
	memcpy(pData,
		   pData+sizeof(iOriginalSize),
		   iOriginalSize);

	//Done
	return iOriginalSize;
}

int CTCPSocketAsyncBlowFish::SendMsg(const char* pData,
									 int iSize)
{
	//Copy the data
	char* pNewData;
	pNewData=new char[iSize+256];

	//Save the size
	memcpy(pNewData,
		   &iSize,
		   sizeof(iSize));

	//Copy the data
	memcpy(pNewData+sizeof(iSize),
		   pData,
		   iSize);

	//Backup the chain
	blowfish::Block aChain(m_aEncryptChain);

	//Encrypt it
	unsigned long ulNewSize;
	ulNewSize=EncryptMemory(pNewData,
							iSize+sizeof(iSize));

	//Try to send it
	int iResult;
	iResult=BlowFishBaseClass::SendMsg(pNewData,
									   ulNewSize);

	//Discard the data
	delete [] pNewData;

	//Did we manage?
	if (iResult!=ulNewSize)
		//Revert the chain
		m_aEncryptChain=aChain;

	//Done
	return iResult;	
}

int CTCPSocketAsyncBlowFish::SendMsg(const char* pData,
									 int iSize,
									 CGenericEvent* pStopEvent)
{
	//Copy the data
	char* pNewData;
	pNewData=new char[iSize+256];

	//Save the size
	memcpy(pNewData,
		   &iSize,
		   sizeof(iSize));

	//Copy the data
	memcpy(pNewData+sizeof(iSize),
		   pData,
		   iSize);

	//Backup the chain
	blowfish::Block aChain(m_aEncryptChain);

	//Encrypt it
	unsigned long ulNewSize;
	ulNewSize=EncryptMemory(pNewData,
							iSize+sizeof(iSize));

	//Try to send it
	int iResult;
	iResult=BlowFishBaseClass::SendMsg(pNewData,
									   ulNewSize,
									   pStopEvent);

	//Discard the data
	delete [] pNewData;

	//Did we manage?
	if (iResult!=ulNewSize)
		//Revert the chain
		m_aEncryptChain=aChain;

	//Done
	return iResult;	
}

unsigned long CTCPSocketAsyncBlowFish::EncryptMemory(char* pBuffer,
													 unsigned long ulSize)const
{
	//Our key
	blowfish::Pad const  pad = blowfish::generatePad(m_sKey.c_str(), 
													 m_sKey.length());
    
	//Round the size	
	unsigned long ulNewSize(ulSize);
	ulNewSize+=blowfish::kBlockSize-1;
    ulNewSize-=ulNewSize % blowfish::kBlockSize;

	//Encrypt with chain
    blowfish::encrypt_CBC(pad, 
						  pBuffer, 
						  pBuffer, 
						  ulNewSize, 
						  &m_aEncryptChain);

    //Done
	return ulNewSize;
}

unsigned long CTCPSocketAsyncBlowFish::DecryptMemory(char* pBuffer,
					  								 unsigned long ulSize)const
{
	//Our key
	blowfish::Pad const  pad = blowfish::generatePad(m_sKey.c_str(), 
													 m_sKey.length());
	     
	
    //Decrypt
    blowfish::decrypt_CBC(pad, 
						  pBuffer, 
						  pBuffer, 
						  ulSize, 
						  &m_aDecryptChain);
         
    //Done
	return ulSize;
}

BOOL CTCPSocketAsyncBlowFish::Accept(CTCPSocket* pNewSocket)
{
	//Give this socket our key
	((CTCPSocketAsyncBlowFish*)pNewSocket)->SetKey(m_sKey);

	//Call upper layer accept
	return CTCPSocketAsync::Accept(pNewSocket);
}

const std::string& CTCPSocketAsyncBlowFish::GetKey()const
{
	return m_sKey;
}

KOMODIA_NAMESPACE_END
