/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#pragma warning(disable:4786)

#include <winsock2.h>
#include <windows.h>

#ifdef _DEBUG
#include "DebugHeap.h"
#endif

#include "TCPSocketAsyncSSL.h"

#include "GenericCriticalSection.h"
#include "OSManager.h"

#include <openssl\ssl.h>   
#include <openssl\err.h>

KOMODIA_NAMESPACE_START

//Our SSL data struct
typedef struct SSLData
{
	SSL*		m_pConnection;
    BIO*		m_pIn;
    BIO*		m_pOut;
	SSL_CTX*	m_pContext;
} _SSLData;

CTCPSocketAsyncSSL::CTCPSocketAsyncSSL(bool bDisableSSL) : m_bDisableSSL(bDisableSSL)
{
	//Set some flags
	m_bVerify=false;
	m_bSend=false;
	m_pFather=NULL;
	m_bSession=false;
	m_pData=NULL;
	m_pCS=NULL;
	m_pCSWrite=NULL;
	m_bEvent=false;
	m_bEventSpawned=false;
	m_bDontQueue=false;
}

CTCPSocketAsyncSSL::~CTCPSocketAsyncSSL()
{
	//Do we have SSL data?
	if (m_pData)
	{
		//Free up some data
		SSL_free(m_pData->m_pConnection);

		//Do we need to free the context?
		if (!m_pFather)
			//Free it
			SSL_CTX_free(m_pData->m_pContext);
	}

	//Delete the data
	delete m_pData;

	//Delete the CS
	delete m_pCS;
	delete m_pCSWrite;
}

void CTCPSocketAsyncSSL::CreateSSLData()
{
	//Create the CS
	m_pCS=COSManager::CreateCriticalSection();
	m_pCSWrite=COSManager::CreateCriticalSection();

	//Create the SSL data
	m_pData=new SSLData;

	//Create the sub data
	//Do we have father?
	if (!m_pFather)
		//The context
		m_pData->m_pContext=SSL_CTX_new(SSLv3_method());
	else
		//Use the father context
		m_pData->m_pContext=m_pFather->m_pData->m_pContext;

	//The connection
	m_pData->m_pConnection=SSL_new(m_pData->m_pContext);

	//The BIOs
	m_pData->m_pIn=BIO_new(BIO_s_mem());
	m_pData->m_pOut=BIO_new(BIO_s_mem());

	//Couple the structures
	SSL_set_bio(m_pData->m_pConnection, 
				m_pData->m_pIn, 
				m_pData->m_pOut);
}

void CTCPSocketAsyncSSL::InitializeSSL()
{
	//Initialize the OpenSSL
	SSL_load_error_strings();                /* readable error messages */
	SSL_library_init();                      /* initialize library */
	OpenSSL_add_all_algorithms();
}

void CTCPSocketAsyncSSL::UninitializeSSL()
{
	//Cleanup code
	ERR_free_strings();
}

int CTCPSocketAsyncSSL::LocalSend(const char* pBuffer,
			  					  unsigned long ulBufferLength,
								  bool bDontDeque,
								  bool bDontFlush)
{
	//Enable the send flag
	m_bSend=true;

	//Reset send flag
	m_bCanSend=false;

	//Our send result
	int iResult;

	{
		{
			//Lock the CS
			CCriticalAutoRelease aRelease(m_pCS);

			//Write the SSL bio
			iResult=SSL_write(m_pData->m_pConnection, 
							  pBuffer, 
							  ulBufferLength);
		}

		//Disconnect flag
		bool bDisc;
		bool bRead;

		//Did we get an error?
		if (iResult<=0 &&
			!HandleSSLError("Send",
							"Failure calling SSL_write",
							iResult,
							bDisc,
							bRead))
		{
			//Set access denied
			::SetLastError(2);

			//Should we disconnect?
			if (bDisc)
			{
				//Close socket
				Close();

				//Which event we want?
				if (m_bEventSpawned)
					//It's connect event
					SocketConnected(-1,
									false);
				else
					//Alert
					SocketClosed(-1,
								 false);
			}

			//Exit with an error
			return -1;
		}
		else if (iResult<=0 &&
				 !bDontDeque)
		{

			{
				//Lock the CS
				CCriticalAutoRelease aRelease(m_pCSWrite);

				//Need to save the data
				AddDataToDeque(m_aPendingDataWrite,
							   pBuffer,
							   ulBufferLength);
			}

			if (!bDontFlush)
				//Flush what we have
				FlushSSLWrite();

			//Failed to send
			return 0;
		}
		else if (iResult<=0 &&
				 bDontDeque)
		{
			//Do we need to flush?
			if (!bDontFlush)
				//Flush what we have
				FlushSSLWrite();

			//Done
			return -1;
		}
	}

	//Do we need to flush?
	if (!bDontDeque ||
		iResult>0)
		//Try to flush the data
		return FlushSSLWrite();
	else
		return 1;
}

int CTCPSocketAsyncSSL::Send(const char* pBuffer,
							 unsigned long ulBufferLength)
{
	//Check if we have SSL disabled
	if (m_bDisableSSL)
		return SSLBaseClass::Send(pBuffer,
			  				  	  ulBufferLength);
	else
		return LocalSend(pBuffer,
						 ulBufferLength,
						 m_bDontQueue,
						 false);
}

bool CTCPSocketAsyncSSL::HandleSSLError(const std::string& rMethod,
										const std::string& rMessage,
										int iResult,
										bool& rKeepAlive,
										bool& rSSLWantRead)const
{
	//Set to keep alive
	rKeepAlive=true;

	//Set the read flag
	rSSLWantRead=false;

	//Our SSL erorr string
	std::string sSSLError;

	//Do we even have an error?
	if (iResult<=0)
	{
		//Start getting the errors
		int iError;
		iError=SSL_get_error(m_pData->m_pConnection,
							 iResult);


		//Is it SSL read?
		if (iError==SSL_ERROR_WANT_READ)
			//Set to read
			rSSLWantRead=true;

		//Is it an SSL warn?
		if (iError==SSL_ERROR_ZERO_RETURN ||
			iError==SSL_ERROR_NONE ||
			iError==SSL_ERROR_WANT_READ)
			return true;

		//Our counter
		int iCounter;
		iCounter=1;

		//Get the errors
		while (iError)
		{
			//Get the actual error
			char aTmp[256];
		    ERR_error_string_n(iError, 
							   aTmp, 
							   sizeof(aTmp));

			//Format it again
			char aTmp2[512];
			sprintf(aTmp2,"SSL error number: %i, error code: %i error string: %s",iCounter,iError,aTmp);

			//Add to our string
			if (!sSSLError.empty())
				sSSLError+=',';

			//Add it to the buffer
			sSSLError+=aTmp2;

			//Next error
			iError=ERR_get_error();
		}

		//Report it
		ReportError(rMethod,
					rMessage,
					sSSLError);

		//Only if already spawned
		if (m_bEventSpawned)
			//And notify
			rKeepAlive=OnSSLError(rMethod,
								  rMessage,
								  sSSLError);
		else
			//Disconnect
			rKeepAlive=false;
	}
	else
		return true;

	//Don't ignore
	return false;
}

int CTCPSocketAsyncSSL::GetDataFromDeque(DataDeque& rDeque,
										 char* pData,
										 int iDataSize)const
{
	//Do we have data at all
	if (rDeque.empty() ||
		!iDataSize)
		return 0;

	//What is the size we take?
	int iSize;
	if (iDataSize>rDeque.size())
		iSize=rDeque.size();
	else
		iSize=iDataSize;

	//Start to iterate the data
	for (int iCounter=0;
		 iCounter<iSize;
		 ++iCounter)
	{
		//Get the data
		pData[iCounter]=rDeque.back();
		rDeque.pop_back();
	}		

	//Done
	return iCounter;
}

void CTCPSocketAsyncSSL::AddDataToDeque(DataDeque& rDeque,
										const char* pData,
										int iDataSize,
										bool bBack)const
{
	//Which insert do we use?
	if (bBack)
		for (int iCounter=iDataSize;
			 iCounter;
			 --iCounter)
			//Insert the data
			rDeque.push_back(pData[iCounter-1]);
	else
		for (int iCounter=0;
			 iCounter<iDataSize;
			 ++iCounter)
			//Insert the data
			rDeque.push_front(pData[iCounter]);
}

int CTCPSocketAsyncSSL::FlushData()
{
	//Flush both ends
	FlushWrite();
	return FlushSSLWrite();
}

int CTCPSocketAsyncSSL::FlushWrite()
{
	//Do we have data?
	if (!m_aPendingDataWrite.empty())
	{
		//Take the data
		char aChunk[2048];
		int iReceive;

		{
			//Lock the CS
			CCriticalAutoRelease aRelease(m_pCSWrite);

			//Take the data
			iReceive=GetDataFromDeque(m_aPendingDataWrite,
									  aChunk,
									  sizeof(aChunk));
		}

		//Did we get?
		if (iReceive)
		{
			//Try to send
			int iResult;
			iResult=LocalSend(aChunk,
							  iReceive,
							  true,
							  true);

			//Did we manage?
			if (iResult>0)
				//We can flush it
				return iResult;
			else
			{
				//Lock the CS
				CCriticalAutoRelease aRelease(m_pCSWrite);

				//We need to add it back
				AddDataToDeque(m_aPendingDataWrite,
							   aChunk,
							   iReceive,
							   true);

				//Exit
				return -1;
			}
		}
	}

	//Done
	return 0;
}

int CTCPSocketAsyncSSL::FlushSSLWrite()
{
	//Data sent counter
	int iDataSent;
	iDataSent=0;

	//Do we have data?
	while (!m_aDataToWrite.empty())
	{
		//Start to get the data
		//Get a chunk
		char aChunk[2048];
		int iBytesToSend;
		iBytesToSend=GetDataFromDeque(m_aDataToWrite,
									  aChunk,
									  sizeof(aChunk));

		//Try to send
		int iResult;
		iResult=SSLBaseClass::Send(aChunk,
								   iBytesToSend);
		
		//Did we manage?
		if (iResult<=0)
		{
			//Push it back
			AddDataToDeque(m_aDataToWrite,
						   aChunk,
						   iBytesToSend,
						   true);

			//Exit
			return iResult;
		}
		else
			//Set data sent
			iDataSent+=iResult;   
	}

	//Do we have pending data
	if (BIO_ctrl_pending(m_pData->m_pOut))
	{
		//Lock the CS
		CCriticalAutoRelease aRelease(m_pCS);

		//Try to get the data
		int iPending;
		while ((iPending=BIO_ctrl_pending(m_pData->m_pOut))>0)
		{
			//Get a chunk
			char aChunk[1024];
			int iBytesToSend;
			iBytesToSend=BIO_read(m_pData->m_pOut, 
								  (void*)aChunk, 
								  sizeof(aChunk));

			//SSL disconnect flag
			bool bDisc;
			bool bRead;

			//Did we get data?
			if (iBytesToSend>0)
				//Add to the buffer
				AddDataToDeque(m_aDataToWrite,
							   aChunk,
							   iBytesToSend);
			else if (!BIO_should_retry(m_pData->m_pOut) &&
					 !HandleSSLError("FlushData",
									 "Failed to call BIO_read",
									 iBytesToSend,
									 bDisc,
									 bRead))
			{
				//Set as error
				::SetLastError(2);

				//Should we disconnect?
				if (bDisc)
				{
					//Exit the CS
					aRelease.Exit();

					//Close socket
					Close();

					//Which event we want?
					if (m_bEventSpawned)
						//It's connect event
						SocketConnected(-1,
										false);
					else
						//Alert
						SocketClosed(-1,
									 false);
				}

				//Exit
				return -1;
			}
		}

		//Exit CS
		aRelease.Exit();

		//Try to flush it
		return FlushData()+iDataSent;
	}
	
	//Done
	return iDataSent;
}

int CTCPSocketAsyncSSL::LocalReceive(char* pBuffer,
									 unsigned long ulBufferLength,
									 bool bFlush)
{
	//Do we have SSL disabled?
	if (m_bDisableSSL)
		return SSLBaseClass::Receive(pBuffer,
								  	 ulBufferLength);

	//Try to read from the socket
	char aChunk[2048];
	int iReceive;
	iReceive=SSLBaseClass::Receive(aChunk,
								   sizeof(aChunk));

	//SSL read flag
	bool bReadAgain;

	//Do we need to read again?
	if (iReceive<sizeof(aChunk))
		bReadAgain=false;
	else
		bReadAgain=true;

	//Did we get data?
	if (iReceive>0)
	{
		{
			//Lock the CS
			CCriticalAutoRelease aRelease(m_pCS);

			//Add to the SSL buffer
			BIO_write(m_pData->m_pIn, 
					  aChunk, 
					  iReceive);
		}

		//Set send flag
		m_bCanSend=true;

		//Check session
		if (!m_bSession &&
			SSL_is_init_finished(m_pData->m_pConnection))
		{
			//Set session
			m_bSession=true;

			//Do we verify?
			if (m_bVerify)
			{
				//No more verify
				m_bVerify=false;

				//Are we OK?
				if (SSL_get_verify_result(m_pData->m_pConnection)!=X509_V_OK)
					//Spawn a bad certificate
					OnSSLEvent(seBadCertificate);
				else
					//We are OK
					OnSSLEvent(seHandshakeFinished);
			}
			else
				//We are OK
				OnSSLEvent(seHandshakeFinished);
		}

		do
		{
			{
				//Lock the CS
				CCriticalAutoRelease aRelease(m_pCS);

				//Start to take SSL data and take it out
				iReceive=SSL_read(m_pData->m_pConnection, 
								  (void*)aChunk, 
								  sizeof(aChunk));
			}

			//SSL disconnect flag
			bool bDisc;
			bool bRead;

			//Check error
			if (!HandleSSLError("Receive",
								"Failed calling SSL_read",
								iReceive,
								bDisc,
								bRead))
			{
				//Set the error
				::SetLastError(2);

				//Should we disconnect?
				if (bDisc)
				{
					//Close socket
					Close();

					//Which event we want?
					if (m_bEventSpawned)
						//It's connect event
						SocketConnected(-1,
										false);
					else
						//Alert
						SocketClosed(-1,
									 false);
				}

				//Exit
				return -1;
			}

			//Did we get it?
			if (iReceive>0)
				//Add it to the deque
				AddDataToDeque(m_aDataToRead,
							   aChunk,
							   iReceive);
			else
				iReceive=-2;
		} while (iReceive>0);
	}

	//Do we have pending data?
	if (m_aDataToRead.empty())
		//Did we had an error?
		if (iReceive<=0)
		{
			//Check if we need to flush data?
			if ((bFlush || !m_aPendingDataWrite.empty()) &&
				iReceive==-2)
				//Flush
				FlushData();
			else if (!bFlush &&
					 iReceive==-2 &&
					 m_bEventSpawned &&
					 !m_bSession)
				//Alert socket he can write
				SocketWrite(0);

			//Do we have SSL wants read?
			if (bReadAgain)
				//Indicate it
				return -3;
			else
				//Done
				return iReceive;
		}
		else
			return 0;
	else
		//Get the data
		return GetDataFromDeque(m_aDataToRead,
								pBuffer,
								ulBufferLength);
}

int CTCPSocketAsyncSSL::Receive(char* pBuffer,
								unsigned long ulBufferLength)
{
	return LocalReceive(pBuffer,
						ulBufferLength,
						!m_bEventSpawned);
}

int CTCPSocketAsyncSSL::Peek(char* pBuffer,
							 unsigned long ulBufferLength)
{
	//Do we have SSL disabled?
	if (m_bDisableSSL)
		return SSLBaseClass::Peek(pBuffer,
								  ulBufferLength);

	//Number of bytes read
	int iBytes=0;

	//Start to peek
	for (int iCount=0;
		 iCount<ulBufferLength &&
		 m_aDataToRead.size()>iCount;
		 ++iCount)
	{
		//Set the data
		pBuffer[iCount]=m_aDataToRead[m_aDataToRead.size()-iCount-1];

		//Next read
		iBytes++;
	}

	//Done
	return iBytes;
}

BOOL CTCPSocketAsyncSSL::Connect(unsigned short usSourcePort,
								 IP aDestinationAddress,
								 unsigned short usDestinationPort,
								 BOOL bDisableAsync,
								 BOOL bForceErrorEvent)
{
	//Do we have SSL disabled?
	if (m_bDisableSSL)
		return SSLBaseClass::Connect(usSourcePort,
									 aDestinationAddress,
								 	 usDestinationPort,
									 bDisableAsync,
									 bForceErrorEvent);

	//Set as SSL connect
	SSL_set_connect_state(m_pData->m_pConnection);

	//Delegate
	if (SSLBaseClass::Connect(usSourcePort,
							  aDestinationAddress,
							  usDestinationPort,
							  bDisableAsync,
							  bForceErrorEvent))
	{
		//Did we had a disable async?
		if (bDisableAsync ||
			IsBlocking())
			//Start the SSL handshake
			StartSSLHandshake();

		//Done
		return true;
	}
	else
		return false;
}

BOOL CTCPSocketAsyncSSL::Connect(IP aDestinationAddress,
								 unsigned short usDestinationPort,
								 BOOL bDisableAsync,
								 BOOL bForceErrorEvent)
{
	//Delegate
	return Connect(0,
				   aDestinationAddress,
				   usDestinationPort,
				   bDisableAsync,
				   bForceErrorEvent);
}

BOOL CTCPSocketAsyncSSL::Connect(const std::string& rDestinationAddress,
								 unsigned short usDestinationPort,
								 BOOL bDisableAsync,
								 BOOL bForceErrorEvent)
{
	//Delegate
	return Connect(0,
				   rDestinationAddress,
				   usDestinationPort,
				   bDisableAsync,
				   bForceErrorEvent);
}

BOOL CTCPSocketAsyncSSL::Connect(unsigned short usSourcePort,
								 const std::string& rDestinationAddress,
								 unsigned short usDestinationPort,
								 BOOL bDisableAsync,
								 BOOL bForceErrorEvent)
{
	//Delegate
	return Connect(usSourcePort,
				   StringToLong(rDestinationAddress),
				   usDestinationPort,
				   bDisableAsync,
				   bForceErrorEvent);
}

bool CTCPSocketAsyncSSL::OnSSLError(const std::string& rMethod,
									const std::string& rMessage,
									const std::string& rSSLError)const
{
	//We are disconnection
	return true;
}

bool CTCPSocketAsyncSSL::LoadCertificateStore(const std::string& rPEMPath)
{
	return (m_bVerify=SSL_CTX_load_verify_locations(m_pData->m_pContext,
												    rPEMPath.c_str(),
													NULL));
}

void CTCPSocketAsyncSSL::OnSSLEvent(SSLEvents)const
{
	//Nothing to do, just a stub
}

bool CTCPSocketAsyncSSL::LoadCertificatesForServer(const std::string& rPublicKey,
												   const std::string& rPrivateKey)
{
	//Set the local certificate from CertFile
	SSL_CTX_use_certificate_file(m_pData->m_pContext, 
								 rPublicKey.c_str(), 
								 SSL_FILETYPE_PEM);

	//Set the private key from KeyFile
	SSL_CTX_use_PrivateKey_file(m_pData->m_pContext, 
							    rPrivateKey.c_str(), 
								SSL_FILETYPE_PEM);

	//Verify private key
	return (m_bServerCert=SSL_CTX_check_private_key(m_pData->m_pContext));
}

void CTCPSocketAsyncSSL::StartSSLHandshake()
{
	//We can only do this if we haven't done any sessions yet
	if (!m_bSend)
	{
		//Send some bogus data
		LocalSend("Bogus",
				  5,
				  true,
				  true);

		//Change flag status
		m_bSend=true;

		//Flush the SSL
		FlushSSLWrite();
	}
}

BOOL CTCPSocketAsyncSSL::Accept(CTCPSocket* pNewSocket)
{
	//Do we have SSL disabled?
	if (!m_bDisableSSL)
		//Give this socket our context
		((CTCPSocketAsyncSSL*)pNewSocket)->SetFather(this);

	//Call upper layer accept
	return SSLBaseClass::Accept(pNewSocket);
}

void CTCPSocketAsyncSSL::SetFather(CTCPSocketAsyncSSL* pFather)
{
	//Save it
	m_pFather=pFather;

	//Create the SSL data
	CreateSSLData();

	//Set as SSL accept
	SSL_set_accept_state(m_pData->m_pConnection);
}

BOOL CTCPSocketAsyncSSL::Create()
{
	//Call upper layer
	if (!SSLBaseClass::Create())
		return false;
	else if (!m_bDisableSSL)
	{
		//Create the SSL structs
		CreateSSLData();

		//Done
		return true;
	}
	else
		//Done
		return true;
}

BOOL CTCPSocketAsyncSSL::SocketConnected(int iErrorCode,
										 BOOL bNoEvent)
{
	//Save event status
	m_bEvent=bNoEvent;

	//Did we manage to connect?
	if (!m_bDisableSSL)
	{
		//Set the event
		SSLBaseClass::SocketConnected(iErrorCode,
									  !iErrorCode);

		//Check for errors
		if (!iErrorCode)
			//Start the SSL handshake
			StartSSLHandshake();

		//Done
		return TRUE;
	}
	else 
		//Delegate
		//But no event
		return SSLBaseClass::SocketConnected(iErrorCode,
											 bNoEvent);
}

BOOL CTCPSocketAsyncSSL::SocketReceive(int iErrorCode,
									   BOOL bNoEvent)
{
	//Are we in session?
	if (m_bSession ||
		iErrorCode ||
		m_bDisableSSL ||
		m_bEventSpawned)
		//Delegate
		return SSLBaseClass::SocketReceive(iErrorCode,
									       bNoEvent);
	else if (!m_bSession &&
			 !iErrorCode)
	{
		//Spawn a fake receive
		//But check for data
		int iReceive;
		iReceive=LocalReceive(NULL,
						      0,
							  false);

		//Flush the data
		if (!FlushData() &&
			!m_bSession &&
			!m_bEventSpawned &&
			iReceive!=-3)
		{
			//Clear the spawn
			m_bEventSpawned=true;

			//Spawn connect
			SSLBaseClass::SocketConnected(0,
										  m_bEvent);
		}

		//Did we get data?
		if (iReceive>=0 &&
			m_bSession)
			//Spawn again
			SocketReceive(0,
						  bNoEvent);

		//Done
		return TRUE;
	}

	//Done
	return TRUE;
}

void CTCPSocketAsyncSSL::DisableSSL()
{
	m_bDisableSSL=true;
}

bool CTCPSocketAsyncSSL::IsHandshakeComplete()const
{
	return m_bSession;
}

void CTCPSocketAsyncSSL::DontQueue()
{
	m_bDontQueue=true;
}

bool CTCPSocketAsyncSSL::IsReadyForSend()const
{
	return m_bSession ||
		   m_bCanSend ||
		   m_bDisableSSL;
}

BOOL CTCPSocketAsyncSSL::SocketWrite(int iErrorCode)
{
	//Can we relay it?
	if (m_bEventSpawned)
		return SSLBaseClass::SocketWrite(iErrorCode);
	else
		return TRUE;
}

KOMODIA_NAMESPACE_END
