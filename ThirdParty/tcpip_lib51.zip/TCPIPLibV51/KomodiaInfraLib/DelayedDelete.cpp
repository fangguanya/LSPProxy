/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#include "stdafx.h"
#include "DelayedDelete.h"

#include "OSManager.h"
#include "GenericCriticalSection.h"
#include "PeriodicThread.h"

#ifdef _MEMORY_DEBUG 
	#define new	   DEBUG_NEW  
	#define malloc DEBUG_MALLOC  
    static char THIS_FILE[] = __FILE__;  
#endif

KOMODIA_NAMESPACE_START

CDelayedDelete::CDelayedDelete()
{
	//Create the CS
	m_pCS=COSManager::CreateCriticalSection();

	//Create the thread
	m_pThread=new CPeriodicThread(DeleteThreadProc);
	m_pThread->Start(1000,
					 (LPVOID)this);
}

CDelayedDelete::~CDelayedDelete()
{
	//Close the thread
	delete m_pThread;

	//Delete all the remaining items
	DeleteAll();

	//Delete the CS
	delete m_pCS;
}

BOOL CDelayedDelete::DeleteThreadProc(LPVOID lpParam)
{
	//Get our class
	CDelayedDelete* pClass;
	pClass=(CDelayedDelete*)lpParam;

	//Our delete vector
	DeleteVector aVec;

	{
		//Lock the CS
		CCriticalAutoRelease aRelease(pClass->m_pCS);

		//Iterate the list
		DeleteList::iterator aIterator;
		aIterator=pClass->m_aData.begin();
		while (aIterator!=pClass->m_aData.end())
			//Can we delete it?
			if (GetTickCount()>=aIterator->dwExpireTime)
			{
				//Add to the vector
				aVec.push_back(*aIterator);

				//Delete from the list
				aIterator=pClass->m_aData.erase(aIterator);
			}
			else
				++aIterator;
	}

	//Iterate the vector
	for (int iCount=0;
		 iCount<aVec.size();
		 ++iCount)
		//Delegate the delete
		(*(aVec[iCount].pProc))(aVec[iCount].lpItemToDelete);

	//Done
	return TRUE;
}

void CDelayedDelete::DeleteAll()
{
	//Our delete vector
	DeleteVector aVec;

	{
		//Lock the CS
		CCriticalAutoRelease aRelease(m_pCS);

		//Iterate the list
		DeleteList::iterator aIterator;
		aIterator=m_aData.begin();
		while (aIterator!=m_aData.end())
		{
			//Add to the vector
			aVec.push_back(*aIterator);

			//Delete from the list
			aIterator=m_aData.erase(aIterator);
		}
	}

	//Iterate the vector
	for (int iCount=0;
		 iCount<aVec.size();
		 ++iCount)
		//Delegate the delete
		(*(aVec[iCount].pProc))(aVec[iCount].lpItemToDelete);
}

void CDelayedDelete::AddItem(LPVOID lpItem,
							 LPDeleteProc pProc,
							 DWORD dwDeleteTimeout)
{
	//Sanity check
	if (!lpItem ||
		!pProc)
		return;

	//Put in the struct
	DeleteStructure aData;
	aData.pProc=pProc;
	aData.lpItemToDelete=lpItem;

	//Some locking
	CCriticalAutoRelease aRelease(m_pCS);

	//Now set time
	aData.dwExpireTime=GetTickCount()+dwDeleteTimeout;

	//Add to the list
	m_aData.insert(m_aData.begin(),
				   aData);
}

KOMODIA_NAMESPACE_END