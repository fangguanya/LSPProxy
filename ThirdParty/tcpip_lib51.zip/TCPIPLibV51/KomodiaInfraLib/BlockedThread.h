/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */


#if !defined(AFX_BLOCKEDTHREAD_H__32030705_FF61_4F49_A60F_1A9D1C4B1FFB__INCLUDED_)
#define AFX_BLOCKEDTHREAD_H__32030705_FF61_4F49_A60F_1A9D1C4B1FFB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ThreadPool.h"

KOMODIA_NAMESPACE_START

class CBlockedThread  
{
public:
	//Do a blocked call
	DWORD BlockedCall(CThreadPool::LPThreadDWORDPoolProc pProc,
					  LPVOID lpData);

	//Ctor and Dtor
	CBlockedThread(CThreadPool::COMInit aInit=CThreadPool::ciNone);
	virtual ~CBlockedThread();
private:
	//Our data
	typedef struct _ThreadData
	{
		CThreadPool::LPThreadDWORDPoolProc	pProc;
		CBlockedThread*						pClass;
		LPVOID								lpData;
		DWORD								dwReturnValue;
		CGenericEvent*						pEvent;
	} ThreadData;
private:
	//No copy ctor
	CBlockedThread(const CBlockedThread& rThread);

	//No assigment operator
	CBlockedThread& operator=(const CBlockedThread& rThread);

	//Our proc
	static void ThreadProc(LPVOID lpData);

	//Our thread pool
	CThreadPool* m_pPool;

	//Our event
	CGenericEvent* m_pEvent;
};

KOMODIA_NAMESPACE_END

#endif // !defined(AFX_BLOCKEDTHREAD_H__32030705_FF61_4F49_A60F_1A9D1C4B1FFB__INCLUDED_)
