/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#include "stdafx.h"
#include "ReferenceCounting.h"

#ifdef _MEMORY_DEBUG 
	#define new	   DEBUG_NEW  
	#define malloc DEBUG_MALLOC  
    static char THIS_FILE[] = __FILE__;  
#endif

KOMODIA_NAMESPACE_START

//----------------------- CReferenceSmartPtr start -----------------------

CReferenceSmartPtr::CReferenceSmartPtr(const CReferenceCounting* pCounter,
									   bool bAutoAdd) : m_pCounter(pCounter)
{
	//Do we need to add
	if (bAutoAdd)
		//Add the ref
		AddRef();
}

CReferenceSmartPtr::~CReferenceSmartPtr()
{
	//Release the ref
	ReleaseRef();
}

const CReferenceCounting* CReferenceSmartPtr::Detach()
{
	//Save to tmp
	const CReferenceCounting* pTmp;
	pTmp=m_pCounter;

	//Clear out var
	m_pCounter=NULL;

	//Done
	return pTmp;
}

long CReferenceSmartPtr::AddRef()
{
	if (m_pCounter)
		return m_pCounter->AddRef();
	else
		return 0;
}

long CReferenceSmartPtr::ReleaseRef()
{
	if (m_pCounter)
		return m_pCounter->ReleaseRef();
	else
		return 0;
}

//----------------------- CReferenceSmartPtr end -----------------------

//----------------------- CReferenceCounting start -----------------------

CReferenceCounting::CReferenceCounting() : m_lCount(1)
{
}

CReferenceCounting::CReferenceCounting(const CReferenceCounting& rReference) : m_lCount(1)
{
}

CReferenceCounting::~CReferenceCounting()
{
}


long CReferenceCounting::AddRef()const
{
	//Add a reference
	return ++m_lCount;
}
	
long CReferenceCounting::ReleaseRef()const
{
	//Was it zero
	if (!m_lCount)
		return 0;

	//Decrese the count
	--m_lCount;

	//Check if we need to destruct
	if (m_lCount<=0)
	{
		//Save the count
		long lCount;
		lCount=m_lCount;

		//Delete this class
		Destruct();

		//Done
		return lCount;
	}
	else
		return m_lCount;
}

void CReferenceCounting::Destruct()const
{
	//Delete the object
	delete this;
}

CReferenceCounting& CReferenceCounting::operator=(const CReferenceCounting& rReference)
{
	//Set zero reference count
	m_lCount=1;

	//Done
	return *this;
}

//----------------------- CReferenceCounting end -----------------------

KOMODIA_NAMESPACE_END