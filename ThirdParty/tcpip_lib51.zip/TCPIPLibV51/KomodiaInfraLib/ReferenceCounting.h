/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#if !defined(AFX_REFERENCECOUNTING_H__6B9BA7CA_EBA0_41AC_9BA6_793FBDB710C7__INCLUDED_)
#define AFX_REFERENCECOUNTING_H__6B9BA7CA_EBA0_41AC_9BA6_793FBDB710C7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "KomodiaSettings.h"

KOMODIA_NAMESPACE_START

class CReferenceCounting;

template<class T>
class CReferenceSPT
{
public:
	//Our operator overload
	virtual T* operator->()
	{
		return m_pCounter;
	}

	//Detach the counter from this smart ptr
	T* Detach()
	{
		//Save to tmp
		T* pTmp;
		pTmp=m_pCounter;

		//Clear out var
		m_pCounter=NULL;

		//Done
		return pTmp;
	}

	//Add a ref
	long AddRef()
	{
		if (m_pCounter)
			return m_pCounter->AddRef();
		else
			return 0;
	}

	//Release a ref
	long ReleaseRef()
	{
		if (m_pCounter)
			return m_pCounter->ReleaseRef();
		else
			return 0;
	}

	//Ctor and Dtor
	//Ctor will do an addref automatically
	CReferenceSPT(T* pCounter,
				  bool bAutoAdd=true) : m_pCounter(pCounter)
	{
		//Do we need to add
		if (bAutoAdd)
			//Add the ref
			AddRef();
	}
	virtual ~CReferenceSPT()
	{
		//Release the ref
		ReleaseRef();
	}
private:
	//No copy ctor
	CReferenceSPT(const CReferenceSPT& rPtr);

	//No assigment operator
	CReferenceSPT& operator=(const CReferenceSPT& rPtr);

	//Our counter
	T* m_pCounter;
};

class CReferenceSmartPtr
{
public:
	//Detach the counter from this smart ptr
	const CReferenceCounting* Detach();

	//Add a ref
	long AddRef();

	//Release a ref
	long ReleaseRef();

	//Ctor and Dtor
	//Ctor will do an addref automatically
	CReferenceSmartPtr(const CReferenceCounting* pCounter,
					   bool bAutoAdd=true);
	virtual ~CReferenceSmartPtr();
private:
	//No copy ctor
	CReferenceSmartPtr(const CReferenceSmartPtr& rPtr);

	//No assigment operator
	CReferenceSmartPtr& operator=(const CReferenceSmartPtr& rPtr);

	//Our counter
	const CReferenceCounting* m_pCounter;
};

class CReferenceCounting  
{
public:
	//Actual reference counting methods
	//Add a reference
	virtual long AddRef()const;
	
	//Remove a reference
	virtual long ReleaseRef()const;

	//Actual destruct function, this will call delete
	virtual void Destruct()const;

	//Assigment operator
	CReferenceCounting& operator=(const CReferenceCounting& rReference);

	//Ctor and Dtor
	CReferenceCounting();
	CReferenceCounting(const CReferenceCounting& rReference);
	virtual ~CReferenceCounting();
private:
	//Our reference count
	mutable long m_lCount;
};

KOMODIA_NAMESPACE_END

#endif // !defined(AFX_REFERENCECOUNTING_H__6B9BA7CA_EBA0_41AC_9BA6_793FBDB710C7__INCLUDED_)
