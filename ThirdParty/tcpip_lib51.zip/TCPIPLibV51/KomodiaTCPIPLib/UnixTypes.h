#ifndef _UnixTypes_H_
#define _UnixTypes_H_

typedef	int	BOOL;
typedef unsigned long DWORD;
typedef void* LPVOID;
typedef char* LPSTR;
typedef const char* LPCSTR;

#define TRUE 1
#define FALSE 0
#define NULL 0

#endif