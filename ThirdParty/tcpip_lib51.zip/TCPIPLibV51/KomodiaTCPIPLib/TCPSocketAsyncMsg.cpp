/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#include "stdafx.h"
#include "TCPSocketAsyncMsg.h"

#include "ErrorHandlerMacros.h"
#include "Array_ptr.h"
#include "GenericEvent.h"

#ifdef _MEMORY_DEBUG 
	#define new	   DEBUG_NEW  
	#define malloc DEBUG_MALLOC  
    static char THIS_FILE[] = __FILE__;  
#endif

#define SEND_CHUNK 1500

KOMODIA_NAMESPACE_START

#define CTCPSocketAsyncMsg_Class "CTCPSocketAsyncMsg"

CTCPSocketAsyncMsg::CTCPSocketAsyncMsg() : CTCPSocketAsync(false)
{
	//Set our name
	SetName(CTCPSocketAsyncMsg_Class);
}

CTCPSocketAsyncMsg::~CTCPSocketAsyncMsg()
{
}

int CTCPSocketAsyncMsg::InternalReceiveMsg(char* pData,
										   int iSize,
										   int& iMoreMessages,
										   bool bRecursed)
{
	try
	{
		//Set the messages
		iMoreMessages=0;

		//Check if we have an available message
		int iMsgSize;
		if ((iMsgSize=CanExtractMsg(m_aData))>0)
		{
			//Check we can return the message
			if (iSize<iMsgSize)
			{
				//Set the size in bytes we need for the buffer
				iMoreMessages=-iMsgSize;

				//Done
				return -1;
			}

			//Save it
			iMsgSize=ExtractMsg(m_aData,
								pData,
								iSize);

			//Did we extract a message?
			if (iMsgSize>0)
			{
				//Do we have more messages?
				if (CanExtractMsg(m_aData)>0)
				{
					//Set more data
					iMoreMessages=1;

					//Done
					return iMsgSize;
				}
				else if (bRecursed)
					return iMsgSize;
			}
			else if (iMsgSize<0)
			{
				//Set the size in bytes we need for the buffer
				iMoreMessages=-iMsgSize;

				//Done
				return -1;
			}
			else if (bRecursed)
				//Done
				return iMsgSize;
		}
		//Should we read on?
		else if (bRecursed)
			return 0;
		
		//We are here because we either extracted data but we need to know if they are more messages
		//Or we have no data at all
		
		//Our tmp data
		char aData[4000];

		//Peek the data
		int iResult;
		iResult=Receive(aData,
						sizeof(aData));

		//Did we had an error?
		if (iResult<0)
			return iResult;

		//Did we get nothing?
		if (iResult==0)
			return iMsgSize;

		//Add the data to the deque
		for (int iCount=0;
			 iCount<iResult;
			 ++iCount)
			m_aData.push_back(aData[iCount]);

		//Process what we got
		int iNewMsg;
		iNewMsg=CanExtractMsg(m_aData);

		//Did we take a message?
		if (iMsgSize)
		{
			//Do we have another message?
			if (iNewMsg>0)
				//Set we have another message
				iMoreMessages=1;

			//Done
			return iMsgSize;
		}

		//Do we have a message?
		return InternalReceiveMsg(pData,
							      iSize,
								  iMoreMessages,
								  true);
	}
	ERROR_HANDLER_RETURN("InternalReceiveMsg",-1)
}


int CTCPSocketAsyncMsg::ReceiveMsg(char* pData,
								   int iSize,
								   int& iMoreMessages)
{
	return InternalReceiveMsg(pData,
							  iSize,
							  iMoreMessages,
							  false);
}

int CTCPSocketAsyncMsg::SendMsg(const char* pData,
								int iSize)
{
	try
	{
		//Create the buffer
		char* pTmp;
		pTmp=new char[iSize+sizeof(DWORD)];

		//Protect it
		CArray_ptr<char> pProtection(pTmp);

		//Copy the size
		memcpy(pTmp,
			   &iSize,
			   sizeof(DWORD));

		//Copy the data
		memcpy(pTmp+sizeof(DWORD),
			   pData,
			   iSize);

		//Try to send it
		int iResult;
		iResult=Send(pTmp,
				     iSize+sizeof(DWORD));

		//Check send size
		if (iResult==iSize+sizeof(DWORD))
			return iSize;
		else
			return iResult;
	}
	ERROR_HANDLER_RETURN("SendMsg",-1)
}

int CTCPSocketAsyncMsg::SendMsg(const char* pData,
								int iSize,
								CGenericEvent* pStopEvent)
{
	try
	{
		//Create the buffer
		char* pTmp;
		pTmp=new char[iSize+sizeof(DWORD)];

		//Protect it
		CArray_ptr<char> pProtection(pTmp);

		//Copy the size
		memcpy(pTmp,
			   &iSize,
			   sizeof(DWORD));

		//Copy the data
		memcpy(pTmp+sizeof(DWORD),
			   pData,
			   iSize);

		//Our new size
		DWORD dwSize(iSize);
		dwSize+=4;

		//Try to send it
		//Our position
		DWORD dwPos;
		dwPos=0;

		while (1)
		{
			//How much we need to send
			DWORD dwSend;
			if (dwPos+SEND_CHUNK>dwSize)
				dwSend=dwSize-dwPos;
			else
				dwSend=SEND_CHUNK;

			//Try to send
			int iResult;
			iResult=Send(pTmp+dwPos,
						 dwSend);

			//Check send size
			if (iResult>0)
				if (iResult!=dwSend)
					return -2;
				//Check for the event
				else if (!pStopEvent->Wait(0))
					return -3;
				else
				{
					//Advance the pointers
					dwPos+=dwSend;

					//Do we need to exit?
					if (dwPos==dwSize)
						return dwPos-sizeof(DWORD);
				}
			else if (GetLastError()!=WSAEWOULDBLOCK)
				return iResult;
			//Sleep and wait for event
			else if (!pStopEvent->Wait(1))
				return -3;
		}
	}
	ERROR_HANDLER_RETURN("SendMsg",-1)
}

int CTCPSocketAsyncMsg::ExtractMsg(CachedDeque& rData,
								   char* pData,
								   int iSize)const
{
	//Check if we can extract a message
	int iMsgSize;
	iMsgSize=CanExtractMsg(rData);

	//Check the verdict
	if (!iMsgSize)
		return 0;

	//Do we have size for it?
	if (iSize<iMsgSize)
		return -iMsgSize;

	//Remove size
	rData.pop_front();
	rData.pop_front();
	rData.pop_front();
	rData.pop_front();

	//Extract the data
	for (int iCounter=0;
		 iCounter<iMsgSize;
		 ++iCounter)
	{
		//Get the data
		pData[iCounter]=rData.front();

		//Remove it
		rData.pop_front();
	}

	//Done, send the size
	return iMsgSize;
}

int CTCPSocketAsyncMsg::CanExtractMsg(const CachedDeque& rData)const
{
	//Check if we have size for size?
	if (rData.size()<sizeof(DWORD))
		return 0;

	//Get the size
	char aConvert[sizeof(DWORD)];
	aConvert[0]=rData[0];
	aConvert[1]=rData[1];
	aConvert[2]=rData[2];
	aConvert[3]=rData[3];

	//Get the size
	DWORD dwSize;
	memcpy(&dwSize,
		   aConvert,
		   sizeof(DWORD));
	
	//Do we have the size inside the deque?
	if (rData.size()-sizeof(DWORD)>=dwSize)
		return dwSize;
	else
		return 0;
}

KOMODIA_NAMESPACE_END
