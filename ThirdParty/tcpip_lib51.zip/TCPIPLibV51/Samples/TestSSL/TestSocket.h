#if !defined(AFX_TESTSOCKET_H__F6BF50E5_FF4D_4018_AB1E_F69FAC75898E__INCLUDED_)
#define AFX_TESTSOCKET_H__F6BF50E5_FF4D_4018_AB1E_F69FAC75898E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TCPSocketAsyncSSL.h"

class CTestSocket : public CTCPSocketAsyncSSL
{
public:
	CTestSocket();
	virtual ~CTestSocket();
protected:
	NO_OnSocketTimeout
	virtual BOOL OnSocketConnect(int iErrorCode);
	virtual BOOL OnSocketAccept(int iErrorCode);
	virtual BOOL OnSocketClose(int iErrorCode);
	NO_OnSocketOOB
	virtual BOOL OnSocketWrite(int iErrorCode);
	virtual BOOL OnSocketReceive(int iErrorCode);
};

#endif // !defined(AFX_TESTSOCKET_H__F6BF50E5_FF4D_4018_AB1E_F69FAC75898E__INCLUDED_)
