// TestSSL.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "TestSocket.h"

#include <stdio.h>
#include <conio.h>

int main(int argc, char* argv[])
{
	//Init sockets
	CSocketBase::InitializeSockets();

	//Init SSL
	CTestSocket::InitializeSSL();

	{
		//Our server
		CTestSocket aServer;
		if (aServer.Create())
		{
			//Set our certificate
			//You have to generate a certificate for the server
			//Look at the CTCPSocketAsyncSSL.h for more information
			if (aServer.LoadCertificatesForServer("c:\\certificate.pem",
												  "c:\\key.pem"))
			{
				//Bind and listen
				aServer.Bind("127.0.0.1",12344);
				aServer.Listen(5);
			}
			else
				//Exit
				return 1;
		}

		//Our socket
		CTestSocket aSocket;
		if (aSocket.Create())
		{
			//This is optional, only if you want to verify that the certificate it legal
			//Look at the CTCPSocketAsyncSSL.h for more information
			aSocket.LoadCertificateStore("c:\\cacert.pem");

			//Try to connect
			if (aSocket.Connect("127.0.0.1",
								12344))
			{
				//And wait
				while (!kbhit())
					Sleep(100);
			}
			else
				printf("No connect!\n");
		}
	}

	//Terminate sockets
	CSocketBase::ShutdownSockets();
	return 0;
}
