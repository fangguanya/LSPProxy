// TestSocket.cpp: implementation of the CTestSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestSocket.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTestSocket::CTestSocket()
{

}

CTestSocket::~CTestSocket()
{

}

BOOL CTestSocket::OnSocketClose(int iErrorCode)
{
	printf("Close\n");

	//Done
	return TRUE;
}

BOOL CTestSocket::OnSocketWrite(int iErrorCode)
{
	printf("Write\n");
	//FlushData();

	//Done
	return TRUE;
}

BOOL CTestSocket::OnSocketReceive(int iErrorCode)
{
	//Read the data
	char aTmp[1025];
	int iReceive;
	iReceive=Receive(aTmp,
					 sizeof(aTmp)-1);

	//Did we get it?
	if (iReceive>0)
	{
		//Terminate it
		aTmp[iReceive]=0;
		
		//Print it
		printf("%s",aTmp);

		//Try again
		OnSocketReceive(0);
	}
	
	//Send something
	char aTmp2[100];
	memset(aTmp2,
		   rand()%26+'A',
		   sizeof(aTmp2));
	Send(aTmp2,
		 sizeof(aTmp2));

	//Done
	return TRUE;
}

BOOL CTestSocket::OnSocketAccept(int iErrorCode)
{
	//Create a new socket
	CTestSocket* pNew;
	pNew=new CTestSocket;

	if (!Accept(pNew))
		delete pNew;

	return TRUE;
}

BOOL CTestSocket::OnSocketConnect(int iErrorCode)
{
	//The request
	std::string sRequest;
	sRequest="GET / HTTP/1.0\r\n\r\n";

	//Send it
	Send(sRequest.c_str(),
		 sRequest.size());

	return TRUE;
}