/*
 *  Copyright (c) 2000-2003 Barak Weichselbaum <barak@komodia.com>
 *  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * Contact info:
 * -------------
 *
 * Site:					http://www.komodia.com
 * Main contact:			barak@komodia.com
 * For custom projects, 
 * consulting, or other
 * paid services:			sales@komodia.com
 */

#include "stdafx.h"
#include "FileLog.h"

#include "ErrorHandlerMacros.h"
#include "OSManager.h"
#include "GenericCriticalSection.h"

#include <time.h>
#include <assert.h>

#ifdef _MEMORY_DEBUG 
	#define new	   DEBUG_NEW  
	#define malloc DEBUG_MALLOC  
    static char THIS_FILE[] = __FILE__;  
#endif

KOMODIA_NAMESPACE_START

CFileLog::CFileLog() : CErrorHandler::CErrorLog(),
					   m_pFile(NULL),
					   m_pCSection(NULL),
					   m_dwMaxLogSize(5000000)
{
	//Create the CS
	m_pCSection=COSManager::CreateCriticalSection();
}

CFileLog::~CFileLog()
{
	//Close the file
	fclose(m_pFile);

	//Delete the CS
	delete m_pCSection;
}

BOOL CFileLog::Initialize(const std::string& rFileName)
{
	//Open's the log file
	try
	{
		//Check if the file is open
		if (m_pFile)
			//close is
			fclose(m_pFile);

		//Which open mode
		BOOL bTruncate;
		bTruncate=FALSE;

		//Do we need to get the file size
		if (m_dwMaxLogSize)
		{
			//Open the file
			HANDLE hFile; 
			hFile=CreateFile(rFileName.c_str(),
							 GENERIC_READ,
							 FILE_SHARE_READ,
							 NULL,
							 OPEN_EXISTING,
							 FILE_ATTRIBUTE_NORMAL,
							 NULL);
 
			//Do we have it?
			if (hFile!=INVALID_HANDLE_VALUE) 
			{ 
				//Get the file size
				DWORD dwSize;
				dwSize=GetFileSize(hFile,
								   NULL);

				//Close the file
				CloseHandle(hFile);

				//Is it bigger
				if (dwSize>m_dwMaxLogSize)
					bTruncate=FALSE;	
			}
		}

		//Now open the file
		if (!bTruncate)
			m_pFile=fopen(rFileName.c_str(),"at");
		else
			m_pFile=fopen(rFileName.c_str(),"wt");

		//Did we manage to open it?
		if (!m_pFile)
			return FALSE;
		else
			return TRUE;
	}
	ERROR_UNKNOWN_RETURN("ReportError",FALSE)
}

void CFileLog::WriteLog(const std::string& rClass, 
						const std::string& rMethod, 
						const std::string& rMessage, 
						CErrorHandler::LogPriority aPriority)
{
	try
	{
#ifdef _DEBUG
		m_aLog.WriteLog(rClass,
						rMethod,
						rMessage,
						aPriority);
#endif
		//Our error string
		std::string sPrefix;

		//Our string to print
		switch (aPriority)
		{
		case CErrorHandler::lpMessage:
			sPrefix="***MESSAGE*** ";
			break;
		case CErrorHandler::lpCritical:
			sPrefix="***CRITICAL*** ";
			break;
		case CErrorHandler::lpError:
			sPrefix="***ERROR*** ";
			break;
		}

		//Lock it
		CCriticalAutoRelease aRelease(m_pCSection);

		//Do we have a prefix
		if (!sPrefix.empty())
			fprintf(m_pFile,"%s",sPrefix.c_str());

		//First write time
		char tmpbuf[128];

		//Get data
		_strdate(tmpbuf);
		fprintf(m_pFile,"%s ",tmpbuf);

		_strtime(tmpbuf);
		fprintf(m_pFile,"%s: ",tmpbuf);
    
		//Write to log
		fprintf(m_pFile,"%s, %s, %s\n",rClass.c_str(),
									   rMethod.c_str(),
									   rMessage.c_str());

		//If error, or auto flush - then flush the data
		if (aPriority==CErrorHandler::lpError ||
			GetAutoFlush())
			fflush(m_pFile);
	}
	ERROR_UNKNOWN("WriteLog")
}

void CFileLog::ReportError(const std::string& rClass,
						   const std::string& rMethod,
						   const std::string& rMessage)
{
	//Delegate call
	WriteLog(rClass,
			 rMethod,
			 rMessage,
			 CErrorHandler::lpError);
}

void CFileLog::WriteMessage(const std::string& rClass,
							const std::string& rMethod,
							const std::string& rMessage,
							CErrorHandler::LogPriority aPriority)
{
	//Delegate call
	WriteLog(rClass,
			 rMethod,
			 rMessage,
			 aPriority);
}

void CFileLog::SetMaxLogSize(DWORD dwSize)
{
	m_dwMaxLogSize=dwSize;
}

KOMODIA_NAMESPACE_END
